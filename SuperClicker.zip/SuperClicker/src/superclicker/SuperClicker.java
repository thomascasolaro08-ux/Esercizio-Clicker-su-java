
package superclicker;

public class SuperClicker  {

   
    public static void main(String[] args) {
    
        new FrameSwing();
    }
    
}
