package superclicker;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class FrameSwing extends JFrame {

    private int contatore = 0;

    public FrameSwing() {
        this.setTitle("super clicker");
        this.setSize(400, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Font f = new Font("Arial", Font.BOLD, 30);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        panel.setBackground(Color.BLUE);

        TitledBorder b = BorderFactory.createTitledBorder("SuperClicker - By TC");
        panel.setBorder(b);

        JLabel label = new JLabel("click: 0");
        label.setFont(f);
        
        label.setBounds(150, 150, 200, 50);
        
        this.add(label);
        JButton Clicker=new JButton("Premimi");
        Clicker.setFont(f);
        
        panel.add(Clicker,BorderLayout.NORTH);
        
        Clicker.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
        contatore++;
        label.setText("click: "+contatore);
        }
        });
    this.add(panel);
    this.setVisible(true);
    
    }

}
